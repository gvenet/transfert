package com.gv.todo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class AddTodoActivity extends AppCompatActivity {
  private EditText et_task;
  private Button btn_add;
  private Button btn_cancel;
  private final List<String> tasks = new ArrayList<>();
  private Spinner spinner;

  @SuppressLint("MissingInflatedId")
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_add_todo);

    et_task = findViewById(R.id.et_task);
    btn_add = findViewById(R.id.btn_add);
    btn_cancel = findViewById(R.id.btn_cancel);


    createSpinner();


    btn_add.setOnClickListener(
      v -> {
        tasks.add(et_task.getText() + " // " + spinner.getSelectedItem().toString());
        et_task.setText("");
      }
    );

    btn_cancel.setOnClickListener(
      v -> {
        Intent concatTasks = new Intent (this, MainActivity.class);
        concatTasks.putExtra("tasks", String.join("\n", tasks));
        startActivity(concatTasks);
        onBackPressed();
      }
    );
  }

  public void createSpinner() {
      spinner = findViewById(R.id.spinner);
      ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
              R.array.priority_values, android.R.layout.simple_spinner_item);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      spinner.setAdapter(adapter);
  }
}
